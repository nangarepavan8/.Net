﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using  System.Net.Sockets;
using System.Threading;
using Newtonsoft.Json;

namespace Client
{
                                                    // CLIENT N
    internal class Program
    {
        private static string userName;

        static void Main(string[] args)
        {
            int port = 8080;
            string IpAdress = "127.0.0.1";

            Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            IPEndPoint ep = new IPEndPoint(IPAddress.Parse(IpAdress), port);

            Program p = new Program();

            clientSocket.Connect(ep);

            Console.WriteLine("Client Socket is Connected..");

            Console.WriteLine("Enter your User Name");

            userName = Console.ReadLine();

            clientSocket.Send(Encoding.ASCII.GetBytes(userName), 0, userName.Length, SocketFlags.None);

            Thread reciverThread = new Thread(new ThreadStart(() => receive(clientSocket)));

            reciverThread.Start();
                            // Write
            while (true)
            {       
                string messageFormClient = null;


                Console.WriteLine("Enter the message : ");
                messageFormClient = Console.ReadLine();
                messageFormClient = userName +" : "+ messageFormClient;
                

                var payLoad = new
                {
                    username = userName,
                    receiver = " ",
                    message = messageFormClient
                };

                //Tranform it to Json object
                string jsonData = JsonConvert.SerializeObject(payLoad);

                //Print the Json object
                //Console.WriteLine(jsonData);

                clientSocket.Send(Encoding.ASCII.GetBytes(jsonData), 0, jsonData.Length,SocketFlags.None);
                
            }
            
        }

      

        //   Read
        public static void receive(Socket clientSocket)
        {
            while (true)
            {
                byte[] messageFromServer = new byte[1024];

                int size = clientSocket.Receive(messageFromServer);

                Console.WriteLine(Encoding.ASCII.GetString(messageFromServer, 0, size));

            }

        }
    }
}
